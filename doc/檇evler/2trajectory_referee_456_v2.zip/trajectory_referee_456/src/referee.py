#!/usr/bin/env python
import math

PKG_NAME="trajectory_referee_456"

XY_CLOSENESS_THRESH=0.2
COSTHETA_CLOSENESS_THRESH=0.5-0.5*math.cos(math.pi/4)
#TIMEOUT=100

PERTURBATIONS_SIZE=1
PERTURBATIONS_SIZE=0

import roslib
roslib.load_manifest(PKG_NAME)
import rospy
import geometry_msgs
import geometry_msgs.msg
import gazebo_msgs
import gazebo_msgs.srv
import gazebo_msgs.msg
import visualization_msgs
import visualization_msgs.msg
import trajectory_msgs
import trajectory_msgs.msg
#import arm_navigation_msgs
#import arm_navigation_msgs.msg
import sys
import time
import tf
import tf.transformations
import signal
import pickle
import random

import roslib.packages

if len(sys.argv)<2:
  print "Please give an argument: which route? One of route1, route2, route3 or route4."
  
if sys.argv[1] not in ["route1","route2","route3","route4"]:
  print "Please give one of route1, route2, route3 or route4."
  sys.exit(1)

assert(sys.argv[1] in ["route1","route2","route3","route4"])

routefname = roslib.packages.get_pkg_dir(PKG_NAME)+"/routes/"+sys.argv[1]+".pkl"
with open(routefname,"r") as f:
  route_raw=pickle.load(f)
  
route=trajectory_msgs.msg.MultiDOFJointTrajectory()

route.joint_names=["mobile_base"]
route.points=[]

marker_array=visualization_msgs.msg.MarkerArray()
marker_cntr=0
for ritem in route_raw:
  route_point=trajectory_msgs.msg.MultiDOFJointTrajectoryPoint()
  route_point.time_from_start=rospy.Duration(ritem[0])
  
  transform=geometry_msgs.msg.Transform()
  transform.translation.x=ritem[1]
  transform.translation.y=ritem[2]
  q=tf.transformations.quaternion_from_euler(0,0,ritem[3])
  transform.rotation.z=q[2]
  transform.rotation.w=q[3]
  transform.rotation.x=q[0]
  transform.rotation.y=q[1]
  
  route_point.transforms.append(transform)

  route.points.append(route_point)
  
  marker=visualization_msgs.msg.Marker()
  marker.header.frame_id="odom"
  marker.id=marker_cntr
  marker_cntr=marker_cntr+1
  marker.type=visualization_msgs.msg.Marker.ARROW
  marker.pose.position.x=ritem[1]
  marker.pose.position.y=ritem[2]
  marker.pose.position.z=0
  marker.pose.orientation=transform.rotation
  marker_array.markers.append(marker)
  marker.scale.x=0.2
  marker.scale.y=0.02
  marker.scale.z=0.02
  marker.color.r=1.0
  marker.color.g=(1.0*marker_cntr)/len(route_raw)
  marker.color.b=1.0-(1.0*marker_cntr)/len(route_raw)
  marker.color.a=1.0
  
rospy.init_node('referee')
rospy.wait_for_service("/gazebo/get_model_state")
rospy.wait_for_service("/gazebo/apply_body_wrench")
route_pub = rospy.Publisher('/route_cmd', trajectory_msgs.msg.MultiDOFJointTrajectory,queue_size=1)
#route_pub = rospy.Publisher('/route_cmd', trajectory_msgs.msg.MultiDOFJointTrajectory,latch=True)
waypoint_pub = rospy.Publisher('/waypoint_cmd',geometry_msgs.msg.Transform,queue_size=1)
marker_pub = rospy.Publisher('/visualization_marker_array', visualization_msgs.msg.MarkerArray,queue_size=1)
#marker_pub = rospy.Publisher('/visualization_marker_array', visualization_msgs.msg.MarkerArray,latch=True)
get_state=rospy.ServiceProxy("/gazebo/get_model_state",gazebo_msgs.srv.GetModelState)
apply_wrench=rospy.ServiceProxy("/gazebo/apply_body_wrench",gazebo_msgs.srv.ApplyBodyWrench)

r=rospy.Rate(100)
#polling_for_sub=True
#def handle(signal,frame):
  ##global polling_for_sub
  ##if polling_for_sub:
    ##print "You pressed Ctrl-C - not waiting"
    ##polling_for_sub=False
  ##else:
  #print "Exiting"
  #sys.exit(0)
#signal.signal(signal.SIGINT,handle)

#try:
  #print "Waiting for a node to listen to /route_cmd to pick up the commanded trajectory before starting measuring the progress."
  #print "If you just want me to start the trial (measuring the progress + adding perturbations), hit Ctrl-C."
  #while route_pub.get_num_connections()<=0  and not rospy.is_shutdown() and  polling_for_sub:
    #r.sleep()
    #marker_pub.publish(marker_array)
      
#except KeyboardInterrupt as ex:
  #print "This should not be reached. If it is, it's probably the divil."

print "Publishing route..."
if not rospy.is_shutdown():
  r.sleep()
  route_pub.publish(route)
  #import pdb;pdb.set_trace()
  waypoint_pub.publish(route.points[0].transforms[0])
  print "Published route. Now it's over to you (will publish it again every second)."
else:
  print "ROS seems to have died - oh well too bad - bye."
  sys.exit(0)
  
#polling_for_sub=False
start_time=time.time()
route_cntr=0
cumulative_dur_error=0
loop_cntr=0

while route_cntr<len(route_raw) and not rospy.is_shutdown():
  
  loop_cntr=loop_cntr+1
  
  marker_pub.publish(marker_array)
  
  nowtime=time.time()
  tdiff=nowtime-start_time
  sget=get_state("mobile_base","world")
  x=sget.pose.position.x
  y=sget.pose.position.y
  
  o=sget.pose.orientation
  q=[o.x,o.y,o.z,o.w]
  ga,gb,theta=tf.transformations.euler_from_quaternion(q)
  
  #publish waypoints constantly
  #print "*"
  #print len(route.points),"--",len(route_raw)
  #print route_cntr
  #print len(route.points[route_cntr].transforms)
  
  wp=route.points[route_cntr].transforms[0]
  #try:
    #t = tflistener.getLatestCommonTime(odom_frame, base_frame)
    #curr_position, curr_orientation_q = tflistener.lookupTransform(odom_frame, base_frame, t)
    #print "t",t
    ##print "update pos"
  ##curr_position, curr_orientation_q = tflistener.lookupTransform(odom_frame, base_frame, t)
  #except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException) as e:
    #print "Couldnt update waypoint",e
  
  waypoint_pub.publish(wp)
  
  #publish route again every second, just in case it was missed the first time. 
  if loop_cntr%100 == 0:
    route_pub.publish(route)
    
  #add mean noise
  if loop_cntr%20==0 and PERTURBATIONS_SIZE>0:
    wrench=geometry_msgs.msg.Wrench()
      
    wrench.force.x=(random.random()-0.5)*PERTURBATIONS_SIZE
    wrench.force.y=(random.random()-0.5)*PERTURBATIONS_SIZE
    wrench.force.z=(random.random()-0.5)*PERTURBATIONS_SIZE
    wrench.torque.x=(random.random()-0.5)*PERTURBATIONS_SIZE
    wrench.torque.y=(random.random()-0.5)*PERTURBATIONS_SIZE
    wrench.torque.z=(random.random()-0.5)*PERTURBATIONS_SIZE
    wret=apply_wrench(body_name="mobile_base::base_footprint",wrench=wrench,duration=rospy.Duration(1.0/100))
    #print wret
    
  
  this_point=route_raw[route_cntr]
  
  
  
  #this_transform=route.points[route_cntr].transforms[0]
  


  #print "  x:",x," y:",y
  #print "  tp[1]:",this_point[1]," tp[2]:",this_point[2]
  #print "LINEAR (",x,"-",this_point[1],",",y,"-",this_point[2],") ANGULAR (",theta,"-",this_point[3],") WP",route_cntr
  linear_error=math.sqrt((x-this_point[1])**2+(y-this_point[2])**2)
  angle_error=0.5-0.5*math.cos((theta-this_point[3]))

  #if tdiff<=this_point[0]:
    #duration_error=0
  #else:
    #duration_error=tdiff-this_point[0]
  duration_error=tdiff-this_point[0]
  
  #if linear_error<=XY_CLOSENESS_THRESH and angle_error<=0.5-0.5*math.cos(THETA_CLOSENESS_THRESH)
  if linear_error<=XY_CLOSENESS_THRESH and angle_error<=COSTHETA_CLOSENESS_THRESH:
    #if linear_error<=XY_CLOSENESS_THRESH:
    print "ACHIEVED WAYPOINT ",route_cntr, "with lateness of",duration_error
    print "  (linear error",linear_error," angle_error",angle_error,")"
    cumulative_dur_error=cumulative_dur_error+duration_error
    marker_array.markers[route_cntr].color.a=0.35
    route_cntr=route_cntr+1
    #route.points=route.points[1:]
  
  r.sleep()
  
print "  "
print "YOUR CUMULATIVE LATENESS IS",cumulative_dur_error,"seconds."
